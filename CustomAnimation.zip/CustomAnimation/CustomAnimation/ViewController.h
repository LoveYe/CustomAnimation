//
//  ViewController.h
//  CustomAnimation
//
//  Created by xczl on 2017/12/20.
//  Copyright © 2017年 黄哲峰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@property (nonatomic,strong)NSIndexPath *currentIndexPath;

@property (nonatomic,strong)UITableView *tableView;
@end

