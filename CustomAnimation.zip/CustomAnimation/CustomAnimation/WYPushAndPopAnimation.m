//
//  WYPushAndPopAnimation.m
//  CustomAnimation
//
//  Created by xczl on 2017/12/20.
//  Copyright © 2017年 黄哲峰. All rights reserved.
//

#import "WYPushAndPopAnimation.h"
#import "ViewController.h"
#import "PopViewController.h"


@interface WYPushAndPopAnimation ()
/**
 *  动画过渡代理管理的是push还是pop
 */
@property (nonatomic, assign) WYType type;

@end

@implementation WYPushAndPopAnimation

+(instancetype)transType:(WYType)type {
    return [[self alloc] initWithType:type];
}
-(instancetype)initWithType:(WYType)type {
    if (self == [super init]) {
        _type = type;
    }
    return self;
}
-(NSTimeInterval)transitionDuration:(id<UIViewControllerContextTransitioning>)transitionContext {
    return 0.75;
}
-(void)animateTransition:(id<UIViewControllerContextTransitioning>)transitionContext {
    switch (_type) {
        case WYTypePush:
            [self doPush:transitionContext];
            break;
        case WYTypePop:
            [self doPop:transitionContext];
            break;
        default:
            break;
    }
}
-(void)doPush:(id<UIViewControllerContextTransitioning>)transitionConntext {
    ViewController *formVc = (ViewController *)[transitionConntext viewControllerForKey:UITransitionContextFromViewControllerKey];
    PopViewController *popVc = (PopViewController *)[transitionConntext viewControllerForKey:UITransitionContextToViewControllerKey];
    UITableViewCell *cell = [formVc.tableView cellForRowAtIndexPath:formVc.currentIndexPath];
    UIView *rootView= [transitionConntext containerView];
    UIView *tempView = [cell.imageView snapshotViewAfterScreenUpdates:NO];
    tempView.frame = [cell.imageView convertRect:cell.imageView.bounds toView:rootView];
    cell.imageView.hidden = YES;
    popVc.view.alpha = 0;
    popVc.imageView.hidden = YES;
    //tempView 添加到containerView中，要保证在最前方，所以后添加
    [rootView addSubview:popVc.view];
    [rootView addSubview:tempView];
    
    //开始做动画
    [UIView animateWithDuration:[self transitionDuration:transitionConntext] delay:0.0 usingSpringWithDamping:0.55 initialSpringVelocity:1 / 0.55 options:0 animations:^{
        tempView.frame = [popVc.imageView convertRect:popVc.imageView.bounds toView:rootView];
        popVc.view.alpha = 1;
    } completion:^(BOOL finished) {
        tempView.hidden = NO;
        popVc.imageView.hidden = NO;
        //如果动画过渡取消了就标记不完成，否则才完成，这里可以直接写YES，如果有手势过渡才需要判断，必须标记，否则系统不会中动画完成的部署，会出现无法交互之类的bug
        [transitionConntext completeTransition:YES];
    }];
    
}
-(void)doPop:(id<UIViewControllerContextTransitioning>)transitionConntext {
    PopViewController*fromVC = (PopViewController *)[transitionConntext viewControllerForKey:UITransitionContextFromViewControllerKey];
    ViewController *toVC = (ViewController *)[transitionConntext viewControllerForKey:UITransitionContextToViewControllerKey];
     UITableViewCell *cell = [toVC.tableView cellForRowAtIndexPath:toVC.currentIndexPath];
    UIView *containerView = [transitionConntext containerView];
    //这里的lastView就是push时候初始化的那个tempView
    UIView *tempView = containerView.subviews.lastObject;
    //设置初始状态
    cell.imageView.hidden = YES;
    fromVC.imageView.hidden = YES;
    tempView.hidden = NO;
    [containerView insertSubview:toVC.view atIndex:0];
    [UIView animateWithDuration:[self transitionDuration:transitionConntext] delay:0.0 usingSpringWithDamping:0.55 initialSpringVelocity:1 / 0.55 options:0 animations:^{
        tempView.frame = [cell.imageView convertRect:cell.imageView.bounds toView:containerView];
        fromVC.view.alpha = 0;
    } completion:^(BOOL finished) {
        //由于加入了手势必须判断
        [transitionConntext completeTransition:![transitionConntext transitionWasCancelled]];
        if ([transitionConntext transitionWasCancelled]) {//手势取消了，原来隐藏的imageView要显示出来
            //失败了隐藏tempView，显示fromVC.imageView
            tempView.hidden = YES;
            fromVC.imageView.hidden = NO;
        }else{//手势成功，cell的imageView也要显示出来
            //成功了移除tempView，下一次pop的时候又要创建，然后显示cell的imageView
            cell.imageView.hidden = NO;
            [tempView removeFromSuperview];
        }
    }];
}
@end
