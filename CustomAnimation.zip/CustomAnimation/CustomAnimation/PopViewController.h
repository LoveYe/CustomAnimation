//
//  PopViewController.h
//  CustomAnimation
//
//  Created by xczl on 2017/12/20.
//  Copyright © 2017年 黄哲峰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PopViewController : UIViewController<UINavigationControllerDelegate>

@property (nonatomic,strong)UIImageView *imageView;

@end
