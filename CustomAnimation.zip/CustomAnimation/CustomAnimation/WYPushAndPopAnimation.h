//
//  WYPushAndPopAnimation.h
//  CustomAnimation
//
//  Created by xczl on 2017/12/20.
//  Copyright © 2017年 黄哲峰. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger,WYType) {
    WYTypePush = 0,
    WYTypePop
};

@interface WYPushAndPopAnimation : NSObject<UIViewControllerAnimatedTransitioning>

+(instancetype)transType:(WYType)type;
-(instancetype)initWithType:(WYType)type;

@end
